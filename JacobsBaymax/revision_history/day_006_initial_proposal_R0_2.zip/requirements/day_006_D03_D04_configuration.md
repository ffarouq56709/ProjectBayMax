# Day 6 / picking our first configuration

Revision **R0.2** · **28 October 2026** · Accountable owner **Faisal Farouq**  
Owner role: project owner. This is a planning proposal; specialist review and physical-task authorization are not recorded.  
Configuration status: **PROVISIONAL**. D-03 and D-04 remain open for the applicable design review.

## The proposal

Keep **five active joints in each leg, with no hip yaw**, for the first straight-line tethered stepping investigation. Keep both ankle axes. Study handling as a **detachable, independently supported module**, used with the robot stationary and mechanically secured. Walking and handling have separate configuration IDs and permits.

These are proposed research arrangements, not a finished design. No actuator, fixture, controller, operating limit, equipment access or test result is assumed to exist.

## 1. What we opened

The mission PDF, engineering baseline and workbook Decisions header all identify **R0.1, 2026-10-23, Faisal Farouq**. The workbook's five decision entries match `revision_history/decisions.csv`. D-03 is **REWORK pending topology decision** and D-04 is **REWORK pending handling decision**. Their release gate is **G2**. [S01-S04]

The architecture and candidate CAD/simulation specifications remain R0.1. `candidate_joints.csv` has no independent revision header; its provenance comes from the R0.1 package and companion `parameters.json`. All ten candidate joints have approved speed, torque and trip limits **NOT SET**. `parameters.json` has `hardware_enable=false` and `approved_limits=null`. The CAD envelopes are not operating limits. [S06-S10]

Day 5 passed its budget-document check. **USD 15,000 remains a scenario; the final funding ceiling is undecided.** JB-R-009 and the original workbook retain the USD 10,000 baseline cap. Prices remain unquoted and procurement remains blocked. Day 4 still has six specialized roles explicitly unassigned. Day 1's scope/charter differences remain unresolved; this proposal does not close them. [S16-S21]

## 2. D-03 / the ten-joint leg layout

Candidate configuration ID: **Y1-LB10-NOYAW-P0**. This is a proposal identifier, not a built configuration or model hash.

Reference frame: **x forward, y left, z up**. Roll is about local x, pitch about local y; the comparison yaw axis is local z. CAD and the eventual simulation/controller must use the same frame, names and units. [S06-S08]

| Per-leg joint | Left joint name | Right joint name | Purpose in the proposed layout |
|---|---|---|---|
| Hip roll | `l_hip_roll` | `r_hip_roll` | Side-to-side leg/body positioning. |
| Hip pitch | `l_hip_pitch` | `r_hip_pitch` | Forward/back leg positioning. |
| Knee pitch | `l_knee_pitch` | `r_knee_pitch` | Leg flexion and extension. |
| Ankle pitch | `l_ankle_pitch` | `r_ankle_pitch` | Fore/aft foot orientation and a candidate balance-control channel. |
| Ankle roll | `l_ankle_roll` | `r_ankle_roll` | Side-to-side foot orientation and a candidate balance-control channel. |

**Count checked: 5 left + 5 right = exactly 10 distinct active lower-body joints.** No hip-yaw joint is hidden in this list. A future handling actuator is outside the lower-body count and must still appear in the total actuator inventory, mass, power and cost models.

### Compare the alternatives

| Option | Joints in each leg | Total | Ten-joint requirement | Effect on ankle balance and scope |
|---|---|---:|---|---|
| **A - proposed** | Hip roll/pitch; knee pitch; ankle pitch/roll | **2 x 5 = 10** | Matches the count in JB-R-005 at proposal level. | Keeps ankle pitch and roll channels. No independently commanded hip-yaw channel for foot heading; heading drift and kinematic coupling still need study. Limit scope to straight-line tethered trials; turning remains excluded. |
| **B - add yaw** | Hip yaw/roll/pitch; knee pitch; ankle pitch/roll | **2 x 6 = 12** | **Unresolved architecture conflict: 2 over the requirement.** | Keeps both ankle channels and adds hip-yaw control. Adds two assemblies and associated interfaces; mass, power, thermal, wiring and cost effects need fresh models. A 20% rise in joint count is not a quoted 20% cost rise. Requires an explicit requirement change and architecture review if pursued. |
| **C - swap ankle roll for yaw** | Hip yaw/roll/pitch; knee pitch; ankle pitch | **2 x (5 + 1 - 1) = 10** | Matches the count but changes the architecture. | Removes the independent ankle-roll channel. Lateral control must be reassessed through the remaining joints, contact behavior and foot placement; yaw cannot be assumed an equivalent replacement. Feasibility is unproven. Not selected by this proposal. |

The direct role of ankle pitch/roll is consistent with the separate balance channels documented by ROBOTIS; its six-axis leg example includes hip yaw and both ankle axes. These examples explain the trade, not component suitability for this robot. [W1-W2]

**Engineering assessment, still to test:** retaining both ankle axes is a reasonable starting point for this narrow stepping study. Keeping an ankle axis does not establish balance: achievable contact forces, friction, center-of-pressure limits, actuator authority, sensing and full-body dynamics all matter. MIT's contact/ZMP discussion provides background, not a stability result for this configuration. [W3]

### Proposed D-03 disposition

Carry **Option A** into detailed no-spend modeling, subject to owner review. Keep D-03 **PROVISIONAL / OPEN** until the G2 evidence and reviews exist. Do not silently edit JB-R-005 or count software-disabled extra joints as a resolved ten-joint design.

Before a freeze, reconcile the exact joint tree across CAD, simulation and controls; obtain link masses/inertias, reachable foot poses, collision and cable-clearance checks, torque-speed/duty/thermal models and the straight-line trajectory/fault-study results. Define acceptable tether loading and heading deviation in the later protocol rather than inventing thresholds today. JB-V-04 and gait tests remain **BLOCKED / NOT EXECUTED**. [S05-S11]

The future gait target stays **three alternating consecutive steps in each of two separate supervised trials**, targeting **0.10-0.15 m/s** with reviewed robot fall protection and a cleared area. A tether or operator pulling the robot through the steps does not establish a successful gait result. [S05, S11-S12]

## 3. D-04 / handling stays stationary

Candidate configuration ID: **Y1-HAND-STATIONARY-P0**. Proposed primary concept: a **detachable handling module with an independent support path**, with the robot stationary and mechanically secured during the demonstration. A counterbalanced arrangement remains an alternative to assess; no counterweight, brake, fixture, lifting mechanism or supplier is selected today. [S02-S04, S06]

The support path is a design requirement to resolve, not an assertion that a suitable support exists. Document the load path for the object, module and secured robot, including power-loss behavior. Counterbalancing alone does not prove retention, stability or a safe stop. Attached module mass belongs in operating robot mass; external fixtures and the object remain separately accounted for. [S02 pp. 7-8, S05]

| Item | Proposed target or assumption | Actual state today |
|---|---|---|
| Object | **2 kg inert object**, retained through the approved trajectory. | No measured payload or retention evidence. |
| Demonstration count | **10 complete supervised repetitions**, separately from walking. Keep interrupted attempts in the record. | **0 executed** in this task; target only. |
| Configuration | Robot stationary and mechanically secured; module supported independently as the concept to evaluate. | Fixture, retention, anchorage and support ratings **UNDEFINED / UNREVIEWED**. |
| Horizontal reach | **0.30 m provisional analysis assumption** from D-04. | **Not an approved reach limit.** Datum and final envelope require a drawing and review. |
| Vertical travel | **0.10 m provisional analysis assumption** from D-04. | **Not an approved travel limit** or an absolute height above the floor. Earlier charter lift-height wording remains unresolved. |
| Walking/handling separation | Payload present inhibits walking; handling requires verified secured support. Separate modes/configurations and permits. | Interlocks **NOT IMPLEMENTED / NOT TESTED**. No controller revision or signed limit-set hash exists in the reviewed evidence. |
| Measurements later | Payload, position, current, temperature, relevant force and stop events; synchronized configuration/log evidence. | Instruments, calibration, sampling rates, trip limits and protocols **NOT DEFINED**. |

Object-only static screen, using the baseline assumption: **2 kg x 9.81 m/s² x 0.30 m = 5.886 N·m**, approximately **5.89 N·m**. This omits module self-weight, motion, friction and margin; it is not an actuator, brake, fixture or anchor rating. No handling speed or operating envelope is approved by this calculation. [S02 p. 8]

### Proposed D-04 disposition

Carry the detachable independently supported concept forward for analysis, subject to owner review. Keep D-04 **PROVISIONAL / OPEN**. The connection arrangement, fixture drawing, support ratings, retention, reach datum, travel, power-loss response, reviewed limits and instrumentation remain unresolved. Before a load trial, the appropriate mechanical/electrical/controls and support reviews, support/payload interlock checks, unloaded commissioning and signed stage permit must be evidenced. JB-V-22 and JB-V-23 remain **BLOCKED / NOT EXECUTED**. [S05, S11-S12]

The proposal keeps the **no person support, no cargo walking and no unsupervised high-energy motion** boundaries. A 5 kg object, turning and untethered walking remain later-scope items. No new medical or care promise is introduced. [S05]

## 4. What today's check actually found

| Check | Observation | Document check |
|---|---|---|
| Exact revisions and decisions | R0.1 headers checked; workbook and CSV statuses match. Candidate list provenance identified. | PASS |
| Active lower-body count | Ten rows; ten unique names; five per side; both ankle axes present; no hip yaw. | PASS |
| Yaw alternatives visible | Adding yaw gives 12; swapping ankle roll gives 10 with a changed lateral-control problem. The 12-joint conflict is explicit. | PASS |
| D-03 and D-04 proposal status | Both proposals present; owner review tracked separately; no G2 freeze claimed. | PASS |
| Handling scope | Stationary, secured, 2 kg, 10 repetitions; 0.30/0.10 m are analysis assumptions only. | PASS |
| Targets distinguished from results | No CAD, simulation, fixture acceptance or physical test claimed. Source verification outcomes retained. | PASS |
| Prior evidence | Existing registers, workbook, daily records and R0.1 release are preserved. Addition hashes and checks are in the Day 6 evidence record. | PASS - sources unchanged; installation check in evidence |

**Day outcome: REWORK.** The proposal is ready; owner review and the Day 6 log entry are pending.

Owner review: **PENDING**. The proposal document and its technical checks are distinct from accepting an architecture or releasing a test. Daily log details are retained in [the evidence record](../evidence/day_006_configuration_review.json). The website entry remains manual; no browser-local task status was changed.

Next owner action: review Option A and the detachable supported handling concept; identify any change before the proposal is carried forward. Day 7 reviews all five decisions. Outstanding funding, facility, appointments, scope reconciliation and technical feasibility remain visible. No purchase, fabrication or powered work is authorized by this record.

## 5. Sources

Local paths are relative to `JacobsBaymax/`. Exact source fingerprints, selected baseline page text, role scope, observations and the R0.2 Day 6 plan reference are recorded in [the evidence record](../evidence/day_006_configuration_review.json).

| Reference | Input and revision | Specific use |
|---|---|---|
| S01 | [Mission PDF](Jacobs_Baymax_Mission_R0_1.pdf), JB-A-01, R0.1, 2026-10-23 | Ten joints, separate handling and exclusions. |
| S02 | [Engineering baseline](../release_archive/R0_1/Jacobs_Baymax_Engineering_Baseline_R0_1.pdf), R0.1, 2026-10-23; pp. 1, 3, 6-8, 18-20 | Revision/status; load paths; targets; mass accounting; handling screen; CAD/model limitations and D-03/D-04. |
| S03-S04 | [Workbook](../budget/Jacobs_Baymax_Control_Workbook_R0_1.xlsx), Decisions A3:C3, rows 6-10; [decision register](../revision_history/decisions.csv), R0.1, 2026-10-23 | Original proposal text, status and G2 dependency. |
| S05 | [Requirements](requirements.csv), R0.1, 2026-10-23 | JB-R-003 to 009, 013 to 015, 040 to 045, 051, 052, 055, 059, 063 and 064. |
| S06 | [Architecture](../architecture/02_system_architecture.md), JB-A-02, R0.1, 2026-10-23 | Ten joint names, coordinate frame and independent support/safety paths. |
| S07-S10 | [Candidate joints](../cad_specifications/candidate_joints.csv), [parameters](../cad_specifications/parameters.json), [CAD specification](../cad_specifications/README.md), [simulation specification](../simulation/README.md), R0.1 package | Count/axes; unset limits; no fabrication model or executed simulation. |
| S11-S12 | [Verification register](../tests/verification_matrix.csv), [demonstration script](../tests/05_demonstration_script.md), R0.1, 2026-10-23 | JB-V-04/05/06/22/23; future protocol, interlocks and evidence. |
| S13-S15 | [Assumptions](../risk_records/assumptions.csv), [hazards](../risk_records/hazards.csv), R0.1; [Day 3 checklist](day_003_year_one_success.csv), R0.2, 2026-10-27 | A-02; fall/payload hazards; target consistency. |
| S16-S20 | [Day 4 roles](day_004_responsibility_matrix.csv), [Day 5 options](day_005_D01_budget_options.md), [budget evidence](../evidence/day_005_budget_review.json), [scenario record](../revision_history/day_005_D01_scenario_record.json), [presentation preference](../revision_history/day_005_document_presentation_notes.md), R0.2, 2026-10-27 | Solo-owner context, unassigned specialties, scenario-only budget and approved document style. |
| S21 | [Day 1 draft](day_001_mission_acceptance.md), R0.2, 2026-10-24 | Unresolved scope/charter differences preserved. |

- **W1:** [ROBOTIS OP development manual](https://emanual.robotis.com/docs/en/platform/op/development/), leg joint lists; accessed 2026-10-28. Six-axis example only; no hardware selection.
- **W2:** [ROBOTIS OP3 ROS packages](https://emanual.robotis.com/docs/en/platform/op3/robotis_ros_packages/), walking balance parameters; accessed 2026-10-28. Separate ankle pitch/roll channels; no gains adopted.
- **W3:** [MIT Underactuated Robotics, Highly-articulated Legged Robots](https://underactuated.csail.mit.edu/humanoids.html), contact/CoP discussion; accessed 2026-10-28. General theory, not validation. W1-W3 are live pages without an immutable revision supplied.

Revision record: R0.2 initial Day 6 proposal, 2026-10-28. No baseline register was promoted, no earlier evidence overwritten and no gate released. Future review decisions require a dated record.
