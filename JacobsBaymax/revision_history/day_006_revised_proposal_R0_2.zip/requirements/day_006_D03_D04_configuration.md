# Day 6 / a concrete Baymax proposal

**R0.2 · 28 October 2026 · Accountable owner: Faisal Farouq**  
Owner role: project owner. Proposal status: **PROVISIONAL / REWORK**.  
Specialist review, procurement release and physical-task authorization remain outstanding.

## What I recommend building

Build a friendly, full-height research companion around a **ten-joint lower body**, a **fixed head and passive upper arms**, and a **separate supported handling module with one vertical axis**. Develop the companion software on the computer first, then integrate it with the reviewed physical configuration. Give the robot its rounded white shell, connected-eye face, warm voice and caregiver-controlled interactions.

This is a specific starting design to analyze. Whether the physical targets are achievable within the mass, money and year depends on the calculations, supplier evidence and staged results below. The design should change when that evidence calls for it.

| Part of the robot | Proposed choice | What must be resolved before ordering or building |
|---|---|---|
| Overall form | **1.829 m target height**, removable rigid white panels, charcoal joint gaps, subtle teal accents and broad flat feet. | Full skeleton, overall dimensions, clearances, panel/cooling access and final height tolerance. |
| Head and arms | **One fixed head; two passive upper-arm assemblies.** Use a connected-eye face, speaker and microphone; show care workflows on a computer display first. | Packaging, microphone/privacy control, sound output, panel access and masses. No powered head/arm joints are included in this proposal. |
| Lower body | **10 active joints: five in each leg**, exactly as named in D-03 below. | Joint centers, bearings/transmissions, torque-speed/duty requirements, output feedback and power-loss behavior. |
| Starting geometry | **0.43 m thigh, 0.43 m shank, 0.32 x 0.22 m foot**, using R0.1 candidate values. | These are modeling inputs. Reconcile hip/ankle offsets, overall height and proportions in CAD; assess collisions and reachable foot poses. |
| Walking configuration | **Y1-LB10-NOYAW-P0**: straight-line stepping, no test payload, rated robot fall protection. | Model and later test two separate three-step trials. Foot heading, step length, timing and allowable tether loads need an accepted protocol. |
| Handling configuration | **Y1-HAND-STATIONARY-P0**: detachable vertical carriage with a retained object tray, independent support, robot mechanically secured and stationary. | Carriage/guide design, fixture interfaces, retention, power-off holding and operating envelope. |
| Commanded-axis inventory | **10 lower-body axes + 1 handling axis = 11 proposed powered axes across the separate setups.** | The ten-joint lower-body rule remains intact. Include the handling drive in the total parts, power and cost inventories; it is not an extra lower-body joint. |
| Mass and cash | **<=55 kg operating robot target**; keep attached modules in that mass. **USD 15,000 is a scenario**, with final ceiling undecided. | Reconcile actual component masses and landed quotes. External support/fixtures and the object are separately accounted for; a lower mass achieved by detaching a module needs its own configuration record. |

The fixed head, passive arms, sensor counts and one-axis handling mechanism are **new proposed implementation choices**, not claims already present in the baseline. D-03/D-04 stay provisional. The other mission demonstrations and exclusions continue to apply. [S01-S10, S22-S24]

## D-03 / how the legs will be arranged


Candidate configuration ID: **Y1-LB10-NOYAW-P0**. This is a proposal identifier, not a built configuration or model hash.

Reference frame: **x forward, y left, z up**. Roll is about local x, pitch about local y; the comparison yaw axis is local z. CAD and the eventual simulation/controller must use the same frame, names and units. [S06-S08]

| Per-leg joint | Left joint name | Right joint name | Purpose in the proposed layout |
|---|---|---|---|
| Hip roll | `l_hip_roll` | `r_hip_roll` | Side-to-side leg/body positioning. |
| Hip pitch | `l_hip_pitch` | `r_hip_pitch` | Forward/back leg positioning. |
| Knee pitch | `l_knee_pitch` | `r_knee_pitch` | Leg flexion and extension. |
| Ankle pitch | `l_ankle_pitch` | `r_ankle_pitch` | Fore/aft foot orientation and a candidate balance-control channel. |
| Ankle roll | `l_ankle_roll` | `r_ankle_roll` | Side-to-side foot orientation and a candidate balance-control channel. |

**Count checked: 5 left + 5 right = exactly 10 distinct active lower-body joints.** No hip-yaw joint is hidden in this list. A future handling actuator is outside the lower-body count and must still appear in the total actuator inventory, mass, power and cost models.

### Compare the alternatives

| Option | Joints in each leg | Total | Ten-joint requirement | Effect on ankle balance and scope |
|---|---|---:|---|---|
| **A - proposed** | Hip roll/pitch; knee pitch; ankle pitch/roll | **2 x 5 = 10** | Matches the count in JB-R-005 at proposal level. | Keeps ankle pitch and roll channels. No independently commanded hip-yaw channel for foot heading; heading drift and kinematic coupling still need study. Limit scope to straight-line tethered trials; turning remains excluded. |
| **B - add yaw** | Hip yaw/roll/pitch; knee pitch; ankle pitch/roll | **2 x 6 = 12** | **Unresolved architecture conflict: 2 over the requirement.** | Keeps both ankle channels and adds hip-yaw control. Adds two assemblies and associated interfaces; mass, power, thermal, wiring and cost effects need fresh models. A 20% rise in joint count is not a quoted 20% cost rise. Requires an explicit requirement change and architecture review if pursued. |
| **C - swap ankle roll for yaw** | Hip yaw/roll/pitch; knee pitch; ankle pitch | **2 x (5 + 1 - 1) = 10** | Matches the count but changes the architecture. | Removes the independent ankle-roll channel. Lateral control must be reassessed through the remaining joints, contact behavior and foot placement; yaw cannot be assumed an equivalent replacement. Feasibility is unproven. Not selected by this proposal. |

The direct role of ankle pitch/roll is consistent with the separate balance channels documented by ROBOTIS; its six-axis leg example includes hip yaw and both ankle axes. These examples explain the trade, not component suitability for this robot. [W1-W2]

**Engineering assessment, still to test:** retaining both ankle axes is a reasonable starting point for this narrow stepping study. Keeping an ankle axis does not establish balance: achievable contact forces, friction, center-of-pressure limits, actuator authority, sensing and full-body dynamics all matter. MIT's contact/ZMP discussion provides background, not a stability result for this configuration. [W3]

### Proposed D-03 disposition

Carry **Option A** into detailed no-spend modeling, subject to owner review. Keep D-03 **PROVISIONAL / OPEN** until the G2 evidence and reviews exist. Do not silently edit JB-R-005 or count software-disabled extra joints as a resolved ten-joint design.

Before a freeze, reconcile the exact joint tree across CAD, simulation and controls; obtain link masses/inertias, reachable foot poses, collision and cable-clearance checks, torque-speed/duty/thermal models and the straight-line trajectory/fault-study results. Define acceptable tether loading and heading deviation in the later protocol rather than inventing thresholds today. JB-V-04 and gait tests remain **BLOCKED / NOT EXECUTED**. [S05-S11]

The future gait target stays **three alternating consecutive steps in each of two separate supervised trials**, targeting **0.10-0.15 m/s** with reviewed robot fall protection and a cleared area. A tether or operator pulling the robot through the steps does not establish a successful gait result. [S05, S11-S12]


## Sensors and feedback / proposed first inventory

These quantities define the analysis proposal, not equipment we own or approved sensor specifications.

| Signal | Proposed quantity and location | Use and evidence needed |
|---|---|---|
| Lower-body joint position | **10 output-side joint-angle feedback channels**, one per active joint. | Match actual joint position to the controller mapping. Confirm reference, calibration, resolution, latency and reboot behavior; motor-side feedback alone may not capture transmission play. |
| Body orientation | **1 pelvis-mounted IMU assembly.** | Estimate body roll/pitch and angular rates for balance feedback. Establish mounting alignment, drift and calibration; IMU integration alone will not establish accurate traveled distance or foot heading. |
| Foot loading | **8 normal-load measurement channels, four under each foot.** | Proposed instrumented sole arrangement for contact and center-of-pressure estimation. Validate the actual load path, cell ratings, calibration, usable range and contact model before relying on it. |
| Tether loading | **1 force-measurement channel in the reviewed support system's load path.** | Disclose support assistance and catches. Installation must fit the qualified support design; no support rating follows from this channel count. |
| Trial reference recording | **2 fixed reference camera views**, side and front, as the proposed evidence setup. | Calibrated visible references and synchronized timing for displacement, foot events and lateral/heading review. Check field of view and occlusion. These are test equipment, not a finished robot vision specification. |
| Handling | **1 carriage position channel**, drive current/temperature readback, relevant load/force sensing, retained-object and secured-support state. | Define the sensors, sampling, calibration and thresholds in the module design. Enumerating these signals does not establish a reliable interlock or safety integrity. |

Current, temperature, fault and available torque-related feedback must also be specified for every chosen drive. No sensor model, sample rate or trip threshold is approved today. [S05-S12; proposed quantities]

## D-04 / a defined handling mechanism

Recommend **one vertical carriage on two parallel linear guides**, carrying a tray that positively retains the inert test object, with **one powered linear drive**. The carriage and guides attach to an independently supported stationary frame. Treat the robot/module attachment as a defined interface to design; the biped's balance controller must not be relied on as the module's support system.

The fixed head and passive arms can give the prototype its Baymax proportions while the handling mechanism performs the narrow object-motion demonstration. This proposal adds a tray/carriage mechanism, not a general-purpose hand or articulated arm. A later gripper or powered arm needs its own task requirements, axis inventory and load model.

| Module feature | Proposed specification | Evidence before a load test |
|---|---|---|
| Test object | **2 kg inert object**, positively retained on the carriage tray. | Calibrated mass record, accepted tolerance and reviewed retention. |
| Motion | **100 mm vertical displacement**, corresponding to R0.1's **0.10 m analysis travel**. No powered horizontal axis. | Drawing with datum and usable travel; speed, acceleration, end stops, clearance and operating limits still to be set. This is not an approved stroke or absolute floor height. |
| Reach | Analyze the existing **0.30 m horizontal reach assumption** as a worst-case candidate. | Define the measurement datum and actual object/module center of mass. Final reach remains open. |
| Repetition | Start at the lower reference, move up the proposed travel, settle/hold, return to the lower reference and settle/hold. **10 complete supervised cycles.** | Reviewed trajectory and completion rules, synchronized logs and all stop/failed attempts retained. Dwell and speed await analysis. |
| Gravity retention | A **power-independent holding/retention arrangement** for the carriage and object is required. | Select and review the holding device and load path, including loss of drive power and retained energy. A screw drive is not assumed self-locking; counterbalancing alone is not acceptance evidence. |
| Enable conditions | Handling is a separate mode; robot secured, support verified, payload retained, correct reviewed configuration and limits present. Payload present inhibits walking enable. | Design review, unloaded interlock/fault checks and a signed stage permit. Conditions listed here are functional requirements, not a completed safety circuit. |
| Future measurements | Carriage position, object/load evidence, current, temperature, relevant force and stop events. | Instrument selection/calibration, synchronization, sample rates, numeric limits and exact controller/limit-set revisions. |

Object-only screens: **2 x 9.81 = 19.62 N** of gravity force, and **2 x 9.81 x 0.30 = 5.886 N m** of static moment at the assumed reach. Both exclude the carriage/module weight, motion, friction and margin. Neither is a drive, brake, fixture or anchor rating. [S02 pp. 7-8; proposed mechanism]

**Proposed D-04 disposition:** use this detachable, independently supported one-axis mechanism as the primary design study. Retain a counterbalanced arrangement as an alternative if the load/support analysis favors it. Both require the applicable engineering review; no mechanism or fixture is released today. The handling module is removed or made incapable of handling during the separately reviewed walking configuration. Any changed mass/configuration is recorded. JB-V-22/23 remain **BLOCKED / NOT EXECUTED**. [S05, S11-S12]

## Controls / how the parts will cooperate

Use three separate responsibilities: **companion software**, **deterministic motion control**, and **independent motion safety hardware**. The conversation model can propose a named action; a deterministic gateway checks the allowed action and current mode. It cannot write joint commands, safety limits or recipient settings. [S06, S23]

| Mode to design | Intended behavior | Condition to evidence |
|---|---|---|
| SOFTWARE | Conversation, games, fictional records, medication log and local mock communication. Hazardous drive enable absent. | Laptop workflow and denied motor-access tests. |
| SECURED SETUP | Robot/module physically secured for inspection and configuration checks. | Actual support configuration, configuration revision, limits and authorized stage record. |
| GAIT | Execute only the reviewed standing/weight-shift/step skills. Handling disabled and no test payload attached. | Applicable prior gates, inspected rated protection, reviewed conditions/limits, supervised permit and synchronized logs. |
| HANDLING | Execute the separately reviewed carriage cycle while stationary and mechanically secured. Walking enable inhibited. | Accepted support/payload conditions, unloaded checks, trajectory and separate permit. |
| FAULT / STOP | Inhibit hazardous motion through the reviewed independent path and retain gravity loads through the mechanical design. | Stop/power-loss/fault evidence. Reset requires human action and does not resume a trajectory. |

These are proposed functional modes, not released software or a safety-rated state machine. Define the fault response, channels, monitored devices and required integrity with the qualified reviewers. A separate controller alone does not establish an independent, adequate safety function.

For the first gait controller study, use finite phases: supported setup, standing, lateral weight transfer, one swing/landing, settling, next alternating swing/landing, and stop. Fit trajectories to the ten-joint kinematics; use calibrated body/foot/joint feedback to study tracking and balance. Review achievable contact forces and contact/friction limits rather than assuming an ankle command will stabilize the robot. [W2-W3; proposed control study]

## What will count as a working first demonstration

Every row below is a future target. **No demonstration is reported as executed by this Day 6 record.**

| Demonstration | Specific behavior to show | Evidence that would establish the result |
|---|---|---|
| Companion | A fictional profile, friendly conversation and clarification, plus trivia, memory, word and matching activities. | Versioned scripts and observed transcripts/screens; record unclear/failed interactions. |
| Records | Add a simulated observation and note; show value/unit/source/time, a trend, a summary and a correction preserving the original. | Fictional fixtures, before/after records and audit export tied to software revision. |
| Medication log | Display original fictional instructions unchanged; record taken/skipped/postponed/no response; draft a scripted missed-dose notice for review. | Original instruction version, scripted responses, notice preview and evidence that a logged response does not imply ingestion. |
| Communication | Preview a fictional report; approve the exact version and recipient; send to an approved local mock endpoint; separate receipt from human review. | Approval/content hash, allowlisted recipient, audit/receipt evidence, denied-send and outage cases. No real message is authorized by this proposal. |
| Legs | **Three alternating steps in each of two separate supervised trials**, target **0.10-0.15 m/s**. | Released configuration, accepted tether criteria, contact/video/position logs, measured distance/time and stop/assistance record; no arrest catch, external propulsion or operator stabilization counted as a successful trial. |
| Handling | **Ten complete supervised cycles with a measured 2 kg inert object**, stationary and mechanically secured, through the later approved trajectory. | Separate support/retention acceptance, permit, payload measurement, per-cycle position/current/temperature/relevant-force/stop logs and reviewer disposition. |

Walking has no test payload. Person lifting, catching, transfer, restraint and support remain excluded. Fictional data only; no clinical authority or medical diagnosis is introduced. Turning, untethered navigation and 5 kg handling remain later-scope work. [S01, S05, S11-S12, S24]

## The engineering work that makes this proposal testable

These are dependencies for the later scheduled design stages, not work claimed complete today or a new purchase schedule.

| Order | Exact output to prepare later | Decision it must support |
|---|---|---|
| 1 | **A common skeleton and joint map:** ten names/axes; 1.829 m stack-up; hip/ankle offsets; feet; panel/cable swept volumes; candidate COM and link inertia table. | Can the ten-joint chain realize the intended foot/body trajectory without collisions or hidden yaw demands? |
| 2 | **Trajectory and load cases:** standing, lateral transfer, three steps, stopping and relevant faults; output joint torque/speed histories and duty/thermal/power needs. | Can a real drive cover sustained and transient loads? The R0.1 55 kg / 0.10 m offset example is **53.96 N m static**; low walking speed does not remove gravity torque. |
| 3 | **A free-base MuJoCo model and reproducible sweeps:** same joint map, actual candidate masses/inertias, contact/friction assumptions, finite actuators/delay, sensing and disclosed compliant tether forces. Pin the simulator version. | Does success survive reasonable uncertainty and faults rather than depend on ideal motors or a hidden fixed-base support? Model input clamps and actuator/joint force limits according to the actual transmission; these are distinct in MuJoCo. [W4] |
| 4 | **Handling and support concept drawings:** carriage, guides, drive/retention options, mass/load path, reach datum, travel, support and robot interfaces, power-loss cases and instrumentation. | Is the independently supported mechanism credible, with no reliance on biped balance or an unproved self-locking assumption? |
| 5 | **Configuration-specific mass and quoted whole-system BOM:** ten complete lower-body assemblies, handling drive, sensors, wiring, power, support, reviews, fabrication, delivery and reserve. | Meet the <=55 kg target and an explicitly chosen cash ceiling. The R0.1 **14 kg lower-actuation allowance / 10 = 1.4 kg average per complete assembly** is a budget to reconcile, not an achieved mass or a procurement specification. |
| 6 | **Qualified design dispositions and staged physical plans:** applicable mechanical, electrical, controls and rigging reviews; drawings, limits, inspection and test permits. | Release only the stage supported by evidence. You remain the owner; specialist help can be scoped to the task when needed. |

If the ten-joint layout fails the kinematic/dynamic study, record the failure and reopen D-03. A twelve-joint yaw layout is an explicit alternative requiring a requirement, mass, power and cash review. If the 55 kg or funding targets fail, rework the configuration, obtain documented resources or revise scope/schedule explicitly. Preserve failed results. This proposal does not assume the more ambitious layout will fit the budget.

## Today's observations and outcome

The mission PDF, baseline and workbook Decisions header were checked as **R0.1 / 2026-10-23 / Faisal Farouq**. The five workbook decision entries match the CSV. D-03 and D-04 retain their original unresolved baseline states; G2 remains unreleased. The headerless candidate-joint CSV is traced to the R0.1 package and companion parameters file. [S01-S10]

| Check | Actual observation | Result for the document |
|---|---|---|
| Lower-body joint count | **10 distinct names, five per leg, both ankle axes and no hip yaw.** | PASS |
| Yaw comparison | Add yaw: **12**, two over the requirement. Swap ankle roll for yaw: **10**, changed lateral-control problem. | PASS |
| Concrete proposal | Fixed head/passive arms, sensor inventory, one-axis carriage, modes, demonstrations and engineering dependencies specified as proposals. | PASS |
| Handling target | **2 kg / 10 repetitions**, stationary and secured; **0.30 m reach / 0.10 m travel** remain analysis assumptions. | PASS |
| Missing evidence visible | No released CAD, executed simulation, selected motor/fixture, approved operating limits or physical test supplied. Candidate limits remain NOT SET; hardware enable is false in parameters. | PASS |
| Funding and people | USD 15,000 scenario only; final ceiling undecided. Six specialized roles remain unassigned; facility/support access unconfirmed. | OPEN |
| Earlier scope differences | Day 1 mission/charter differences, including height tolerance and lift-height wording, remain unresolved. | OPEN |

**Day 6 result: REWORK.** The owner requested a more specific engineering proposal. This revised proposal is ready for owner review; no acceptance of either architecture decision is inferred. Daily log details are retained in [the structured evidence](../evidence/day_006_configuration_review.json). The website outcome remains manual and has not been changed by this work.

This document check establishes a traceable proposal. D-03/D-04 remain **PROVISIONAL / OPEN**, actual robot results remain unexecuted, and no procurement or physical gate is released. Stop this desk-work task if it would introduce real patient data, clinical authority, unapproved spending or powered motion.

## Sources


Local paths are relative to `JacobsBaymax/`. Exact source fingerprints, role scope, observations and the R0.2 Day 6 plan reference are recorded in [the evidence record](../evidence/day_006_configuration_review.json).

| Reference | Input and revision | Specific use |
|---|---|---|
| S01 | [Mission PDF](Jacobs_Baymax_Mission_R0_1.pdf), JB-A-01, R0.1, 2026-10-23 | Ten joints, separate handling and exclusions. |
| S02 | [Engineering baseline](../release_archive/R0_1/Jacobs_Baymax_Engineering_Baseline_R0_1.pdf), R0.1, 2026-10-23; pp. 1, 3, 6-8, 18-20 | Revision/status; load paths; targets; mass accounting; handling screen; CAD/model limitations and D-03/D-04. |
| S03-S04 | [Workbook](../budget/Jacobs_Baymax_Control_Workbook_R0_1.xlsx), Decisions A3:C3, rows 6-10; [decision register](../revision_history/decisions.csv), R0.1, 2026-10-23 | Original proposal text, status and G2 dependency. |
| S05 | [Requirements](requirements.csv), R0.1, 2026-10-23 | JB-R-003 to 009, 013 to 015, 040 to 045, 051, 052, 055, 059, 063 and 064. |
| S06 | [Architecture](../architecture/02_system_architecture.md), JB-A-02, R0.1, 2026-10-23 | Ten joint names, coordinate frame and independent support/safety paths. |
| S07-S10 | [Candidate joints](../cad_specifications/candidate_joints.csv), [parameters](../cad_specifications/parameters.json), [CAD specification](../cad_specifications/README.md), [simulation specification](../simulation/README.md), R0.1 package | Count/axes; unset limits; no fabrication model or executed simulation. |
| S11-S12 | [Verification register](../tests/verification_matrix.csv), [demonstration script](../tests/05_demonstration_script.md), R0.1, 2026-10-23 | JB-V-04/05/06/22/23; future protocol, interlocks and evidence. |
| S13-S15 | [Assumptions](../risk_records/assumptions.csv), [hazards](../risk_records/hazards.csv), R0.1; [Day 3 checklist](day_003_year_one_success.csv), R0.2, 2026-10-27 | A-02; fall/payload hazards; target consistency. |
| S16-S20 | [Day 4 roles](day_004_responsibility_matrix.csv), [Day 5 options](day_005_D01_budget_options.md), [budget evidence](../evidence/day_005_budget_review.json), [scenario record](../revision_history/day_005_D01_scenario_record.json), [presentation preference](../revision_history/day_005_document_presentation_notes.md), R0.2, 2026-10-27 | Solo-owner context, unassigned specialties, scenario-only budget and approved document style. |
| S21 | [Day 1 draft](day_001_mission_acceptance.md), R0.2, 2026-10-24 | Unresolved scope/charter differences preserved. |

- **W1:** [ROBOTIS OP development manual](https://emanual.robotis.com/docs/en/platform/op/development/), leg joint lists; accessed 2026-10-28. Six-axis example only; no hardware selection.
- **W2:** [ROBOTIS OP3 ROS packages](https://emanual.robotis.com/docs/en/platform/op3/robotis_ros_packages/), walking balance parameters; accessed 2026-10-28. Separate ankle pitch/roll channels; no gains adopted.
- **W3:** [MIT Underactuated Robotics, Highly-articulated Legged Robots](https://underactuated.csail.mit.edu/humanoids.html), contact/CoP discussion; accessed 2026-10-28. General theory, not validation. W1-W3 are live pages without an immutable revision supplied.


Additional inputs read for this revision:

- **S22:** [Mass budget](../budget/mass_budget.csv), R0.1 package. Component allocations, attached-module accounting and passive upper-limb allowance.
- **S23:** [Architecture interface diagram](../architecture/system_architecture.mmd), R0.1 package. Separation of companion proposals, deterministic services, motion and independent safety.
- **S24:** [Feature backlog specification](08_feature_backlog.md), JB-A-08, R0.1, 2026-10-23. Software-first scope and supported-module option.
- **W4:** [MuJoCo Modeling documentation](https://mujoco.readthedocs.io/en/stable/modeling.html), kinematic tree and force-limit sections, accessed 2026-10-28. Live stable documentation; an implementation version is not yet pinned. Used for the modeling plan, not an executed model claim.

Revision record: **R0.2, revised proposal, 2026-10-28**. The owner requested a more specific proposal aimed at a working Baymax. Added explicit implementation choices, measurement inventory, handling mechanism, control modes, demonstration evidence and analysis dependencies. The earlier proposal and evidence are preserved; baseline registers and all earlier daily records remain unchanged.

Original-proposal archive: [initial Day 6 records](../revision_history/day_006_initial_proposal_R0_2.zip). The four original records and their checksums are retained unchanged.
